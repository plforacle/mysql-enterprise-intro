<?php
    // Database credentials
    define('DB_SERVER', 'mysql1');// MDS server IP address
    define('DB_USERNAME', 'appuser');
    define('DB_PASSWORD', 'Welcome1!');
    define('DB_NAME', 'employees');
    //Attempt to connect to MySQL database
    $conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    //$conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if($conn === false){
die("ERROR: Could not connect. " . mysqli_connect_error());
    }
    // Print host information
    echo 'Successfull Connect.';
    echo 'Host info: ' . mysqli_get_host_info($conn);
    ?>
