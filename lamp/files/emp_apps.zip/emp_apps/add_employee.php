<?php
require_once "config.php";

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $emp_no = $_POST['emp_no'];
    $birth_date = $_POST['birth_date'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $gender = $_POST['gender'];
    $hire_date = $_POST['hire_date'];

    $sql = "INSERT INTO employees (emp_no, birth_date, first_name, last_name, gender, hire_date)
            VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssss", $emp_no, $birth_date, $first_name, $last_name, $gender, $hire_date);
    
    if ($stmt->execute()) {
        echo "New employee record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Employee</title>
</head>
<body>
    <?php include 'menu.php'; ?>
    <h2>Add New Employee</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        Employee Number: <input type="number" name="emp_no" required><br>
        Birth Date: <input type="date" name="birth_date" required><br>
        First Name: <input type="text" name="first_name" maxlength="14" required><br>
        Last Name: <input type="text" name="last_name" maxlength="16" required><br>
        Gender: 
        <select name="gender" required>
            <option value="M">Male</option>
            <option value="F">Female</option>
        </select><br>
        Hire Date: <input type="date" name="hire_date" required><br>
        <input type="submit" value="Add Employee">
    </form>
</body>
</html>