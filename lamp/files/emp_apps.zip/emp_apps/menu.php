<nav>
    <ul style="list-style-type: none; padding: 0; background-color: #f1f1f1; overflow: hidden; margin: 0;">
        <li style="float: left;"><a href="add_employee.php" style="display: block; color: black; text-align: center; padding: 14px 16px; text-decoration: none;">Add Employee</a></li>
        <li style="float: left;"><a href="list_employees.php" style="display: block; color: black; text-align: center; padding: 14px 16px; text-decoration: none;">List Employees</a></li>
        <li style="float: left;"><a href="employees_mask.php" style="display: block; color: black; text-align: center; padding: 14px 16px; text-decoration: none;">List Employees_mask</a></li>
        <li style="float: left;"><a href="employees_mask_after.php" style="display: block; color: black; text-align: center; padding: 14px 16px; text-decoration: none;">List Employees_mask_after</a></li>
    </ul>
</nav>
